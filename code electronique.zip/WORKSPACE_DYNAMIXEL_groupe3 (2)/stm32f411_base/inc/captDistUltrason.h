#ifndef INC_CAPTDISTULTRASON_H_
#define INC_CAPTDISTULTRASON_H_

#include "main.h"

void captDistUS_Measure(uint16_t);
uint16_t captDistUS_Get(uint16_t);

#endif /* INC_CAPTDISTULTRASON_H_ */
