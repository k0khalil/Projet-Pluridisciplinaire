/*
 * SystemClock.h
 */

#ifndef INC_SYSTEMCLOCK_H_
#define INC_SYSTEMCLOCK_H_


#include "main.h"

HAL_StatusTypeDef SystemClock_Config(void);

#endif /* INC_SYSTEMCLOCK_H_ */
