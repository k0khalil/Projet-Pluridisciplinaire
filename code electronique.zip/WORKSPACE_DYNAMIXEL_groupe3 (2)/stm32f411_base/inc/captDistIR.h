/*
 * IRMeasure.h
 */

#ifndef INC_CAPTDISTIR_H_
#define INC_CAPTDISTIR_H_

#include "main.h"


void captDistIR_Init(void);
int captDistIR_Get(int*);


#endif /* INC_CAPTDISTIR_H_ */
