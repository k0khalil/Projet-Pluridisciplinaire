/*
 * TickTimer.h
 */

#ifndef INC_TICKTIMER_H_
#define INC_TICKTIMER_H_

#include "main.h"

void tickTimer_Init(int period);

#endif /* INC_TICKTIMER_H_ */
