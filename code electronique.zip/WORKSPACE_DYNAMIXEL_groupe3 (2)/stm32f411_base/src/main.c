#include "main.h"

// openocd -s /local/sdk_elec/openocd/share/openocd/scripts -f board/st_nucleo_f4.cfg -c init

extern TIM_HandleTypeDef    TimHandle_period;
extern uint8_t rec_buf1[NB_CAR_TO_RECEIVE+1];


#define DYN_ID1	1
#define DYN_ID2  2


//=====================================================================================
//  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    MAIN    <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//=====================================================================================

int main(void)
{
    HAL_Init(); // passage par stm32f4xx_hal_msp.c : configuration des broches
    SystemClock_Config();

    uart2_Init();           // CABLE
    uart6_Init();           // dxlAMIXELS
    uart1_Init();	    //zigbee
    //tickTimer_Init(3000);   // 3000 ms
    //i2c1_Init();          // Modifier stm32f4xx_hal_msp.c pour configurer les broches
    //spi1Init();           // Modifier stm32f4xx_hal_msp.c pour configurer les broches
    HAL_Delay(500);
    

    //------------------------------------------------------------
    //  TEST LIAISON SERIE
    // ouvrir gtkterm ou minicom / /dev/ttyCAM0 baudrate : 115200-8-N-1
    //------------------------------------------------------------
    term_printf("hello world \n\r");
    
    

    /*char new_id = 2;
	dxl_change_id(DYN_ID, new_id);*/  



    // CHANGE BAUDRATE
 /*  dxl_setBaudrate(DYN_ID, 1);

   dxl_factoryReset(DYN_ID);
*/

	



	

	
    //------------------------------------------------------------
    //  BLINK LED : PA5
    //------------------------------------------------------------
    while(1)
    {
		
		
		term_printf("%c\n\r",(char)rec_buf1[0]);	//affichage sur le terminale des caractères reçus
		term_printf("%c\n\r",(char)rec_buf1[1]);
		
		
		
	
		switch ((char)rec_buf1[0]){
		
			case 'Z':
		
				term_printf("avance \n\r");
		
				dxl_torque(DYN_ID1, TORQUE_OFF);
				dxl_setOperatingMode(DYN_ID1, VELOCITY_MODE);
				dxl_torque(DYN_ID1, TORQUE_ON);
				dxl_setGoalVelocity(DYN_ID1, -100);
		
       
		
				dxl_torque(DYN_ID2, TORQUE_OFF);
				dxl_setOperatingMode(DYN_ID2, VELOCITY_MODE);
				dxl_torque(DYN_ID2, TORQUE_ON);
				dxl_setGoalVelocity(DYN_ID2, 100);
				break;
			
			case 'S':
		
				term_printf("recule\n\r");
		
				dxl_torque(DYN_ID1, TORQUE_OFF);
				dxl_setOperatingMode(DYN_ID1, VELOCITY_MODE);
				dxl_torque(DYN_ID1, TORQUE_ON);
				dxl_setGoalVelocity(DYN_ID1, 100);
		
       
		
				dxl_torque(DYN_ID2, TORQUE_OFF);
				dxl_setOperatingMode(DYN_ID2, VELOCITY_MODE);
				dxl_torque(DYN_ID2, TORQUE_ON);
				dxl_setGoalVelocity(DYN_ID2, -100);
				break;

			case 'D':
		
				term_printf("droite\n\r");
		
				dxl_torque(DYN_ID1, TORQUE_OFF);
				dxl_setOperatingMode(DYN_ID1, VELOCITY_MODE);
				dxl_torque(DYN_ID1, TORQUE_ON);
				dxl_setGoalVelocity(DYN_ID1, 0);
		
       
		
				dxl_torque(DYN_ID2, TORQUE_OFF);
				dxl_setOperatingMode(DYN_ID2, VELOCITY_MODE);
				dxl_torque(DYN_ID2, TORQUE_ON);
				dxl_setGoalVelocity(DYN_ID2, 100);
				break;


			case 'Q':
		
				term_printf("gauche\n\r");
		
				dxl_torque(DYN_ID1, TORQUE_OFF);
				dxl_setOperatingMode(DYN_ID1, VELOCITY_MODE);
				dxl_torque(DYN_ID1, TORQUE_ON);
				dxl_setGoalVelocity(DYN_ID1, -100);
		
       
		
				dxl_torque(DYN_ID2, TORQUE_OFF);
				dxl_setOperatingMode(DYN_ID2, VELOCITY_MODE);
				dxl_torque(DYN_ID2, TORQUE_ON);
				dxl_setGoalVelocity(DYN_ID2, 0);
				break;

			default:
				dxl_torque(DYN_ID1, TORQUE_OFF);
				dxl_setOperatingMode(DYN_ID1, VELOCITY_MODE);
				dxl_torque(DYN_ID1, TORQUE_ON);
				dxl_setGoalVelocity(DYN_ID1, 0);
		
       
		
				dxl_torque(DYN_ID2, TORQUE_OFF);
				dxl_setOperatingMode(DYN_ID2, VELOCITY_MODE);
				dxl_torque(DYN_ID2, TORQUE_ON);
				dxl_setGoalVelocity(DYN_ID2, 0);
				break;
	
			}    
    
	}
  
return 0;

}

//=====================================================================================
//      GPIO EXTERNAL INTERRUPT CALLBACK
//=====================================================================================
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    switch(GPIO_Pin)
    {
    case GPIO_PIN_0 :
                    break;
    case GPIO_PIN_13 :  term_printf("USER BUTTON PUSHED \n\r"); // USER BUTTON
                    break;
    default :       break;

    }
}
//=====================================================================================
//      TIMER INTERRUPT CALLBACK
//=====================================================================================
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim==&TimHandle_period)
    {
        term_printf("Tick Timer period elapsed \n\r");
    }
}

//=====================================================================================
