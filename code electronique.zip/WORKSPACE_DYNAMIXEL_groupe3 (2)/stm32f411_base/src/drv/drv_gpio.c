/*
 * drv_gpio.c
 */

#include "drv_gpio.h"

extern void quadEncoder_CallbackIndexL(void);
extern void quadEncoder_CallbackIndexR(void);



