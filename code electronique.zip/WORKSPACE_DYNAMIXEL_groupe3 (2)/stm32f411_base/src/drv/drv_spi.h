/*
 * drv_spi.h
 */

#ifndef SRC_DRV_DRV_SPI_H_
#define SRC_DRV_DRV_SPI_H_

#include "main.h"

void spi1Init(void);
uint8_t spi1Transfer(uint8_t out);


#endif /* SRC_DRV_DRV_SPI_H_ */
